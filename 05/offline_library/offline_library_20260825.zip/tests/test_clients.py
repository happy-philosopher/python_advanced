import pytest


@pytest.mark.create
@pytest.mark.client
async def test_create_client(client):
    data = {"full_name": "Иван Петров", "phone": "+79991234567", "email": "ivan@test.ru"}
    response = await client.post("/clients/", json=data)
    assert response.status_code == 201
    client_data = response.json()
    assert client_data["full_name"] == data["full_name"]
    assert client_data["phone"] == data["phone"]
    assert client_data["email"] == data["email"]
    assert "id" in client_data


@pytest.mark.parametrize(
    "invalid_data, expected_error",
    [
        ({"full_name": "", "phone": "+79991234567", "email": "ivan@test.ru"}, "String should have at least 1 character"),
        ({"full_name": "Иван Петров", "phone": "", "email": "ivan@test.ru"}, "String should have at least 1 character"),
        ({"full_name": "Иван Петров", "phone": "+79991234567", "email": ""}, "String should have at least 1 character"),
        ({"full_name": "Иван Петров", "phone": "12345", "email": "ivan@test.ru"}, "String should have at least 15 characters"),
        ({"full_name": "Иван Петров", "phone": "+79991234567", "email": "invalid_email"}, "value is not a valid email address"),
        ({"full_name": "Иван Петров", "phone": "+79991234567"}, "Field required")
    ]
)
@pytest.mark.validation
@pytest.mark.client
async def test_invalid_create_client(client, invalid_data, expected_error):
    response = await client.post("/clients/", json=invalid_data)
    assert response.status_code == 422
    errors = response.json()["detail"]
    assert expected_error in str(errors)


@pytest.mark.read
@pytest.mark.client
async def test_get_clients(client):
    await client.post("/clients/", json={"full_name": "Тестовый клиент", "phone": "+79991234567", "email": "test@test.ru"})
    response = await client.get("/clients/")
    assert response.status_code == 200
    clients = response.json()
    assert len(clients) == 1
    assert clients[0]["full_name"] == "Тестовый клиент"


@pytest.mark.update
@pytest.mark.client
async def test_update_client(client):
    create_resp = await client.post("/clients/", json={"full_name": "Старый клиент", "phone": "+79991234567", "email": "old@test.ru"})
    client_id = create_resp.json()["id"]
    update_data = {"full_name": "Обновленный клиент", "phone": "+79997654321", "email": "new@test.ru"}
    response = await client.put(f"/clients/{client_id}", json=update_data)
    assert response.status_code == 200
    updated = response.json()
    assert updated["full_name"] == "Обновленный клиент"
    assert updated["phone"] == "+79997654321"
    assert updated["email"] == "new@test.ru"


@pytest.mark.delete
@pytest.mark.client
async def test_delete_client(client):
    create_resp = await client.post("/clients/", json={"full_name": "Тестовый клиент", "phone": "+79991234567", "email": "test@test.ru"})
    client_id = create_resp.json()["id"]
    response = await client.delete(f"/clients/{client_id}")
    assert response.status_code == 200
    get_resp = await client.get(f"/clients/{client_id}")
    assert get_resp.status_code == 404


@pytest.mark.parametrize(
    "email, expected_error",
    [
        ("valid@email.ru", None),
        ("invalid_email", "value is not a valid email address"),
        ("test@", "value is not a valid email address"),
        ("", "String should have at least 1 character"),
        ("a" * 151 + "@test.ru", "String should have at most 150 characters")
    ]
)
@pytest.mark.validation
@pytest.mark.client
async def test_email_validation(client, email, expected_error):
    data = {"full_name": "Тестовый клиент", "phone": "+79991234567", "email": email}
    response = await client.post("/clients/", json=data)
    if expected_error:
        assert response.status_code == 422
        assert expected_error in str(response.json()["detail"])
    else:
        assert response.status_code == 201


@pytest.mark.parametrize(
    "phone, expected_error",
    [
        ("+79991234567", None),
        ("1234567890", "String should have at least 15 characters"),
        ("+7999123456", "String should have at least 15 characters"),
        ("+799912345678", "String should have at most 15 characters"),
        ("", "String should have at least 1 character"),
        ("abcdefghij", "String should match pattern '^\\+[0-9]{14}$'")
    ]
)
@pytest.mark.validation
@pytest.mark.client
async def test_phone_validation(client, phone, expected_error):
    data = {"full_name": "Тестовый клиент", "phone": phone, "email": "test@test.ru"}
    response = await client.post("/clients/", json=data)
    if expected_error:
        assert response.status_code == 422
        assert expected_error in str(response.json()["detail"])
    else:
        assert response.status_code == 201


@pytest.mark.parametrize(
    "full_name_length, expected_error",
    [
        (150, None),
        (151, "String should have at most 150 characters"),
        (1, None),
        (0, "String should have at least 1 character")
    ]
)
@pytest.mark.validation
@pytest.mark.client
async def test_full_name_validation(client, full_name_length, expected_error):
    full_name = "a" * full_name_length if full_name_length > 0 else ""
    data = {"full_name": full_name, "phone": "+79991234567", "email": "test@test.ru"}
    response = await client.post("/clients/", json=data)
    if expected_error:
        assert response.status_code == 422
        assert expected_error in str(response.json()["detail"])
    else:
        assert response.status_code == 201
