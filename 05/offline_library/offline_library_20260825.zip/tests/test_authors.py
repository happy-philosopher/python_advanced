import pytest


@pytest.mark.create
@pytest.mark.author
async def test_create_author(client):
    data = {
        "name": "Александр Пушкин",
        "bio": "Русский писатель"
    }
    response = await client.post("/authors/", json=data)
    assert response.status_code == 201
    author = response.json()
    assert author["name"] == data["name"]
    assert "id" in author


@pytest.mark.parametrize(
    "invalid_data, expected_error",
    [
        ({"name": 123}, "Input should be a valid string"),
        ({"bio": None}, "Field required"),  # bio является обязательным? Проверить схему
        ({}, "Field required")
    ]
)
@pytest.mark.validation
@pytest.mark.author
async def test_invalid_create_author(client, invalid_data, expected_error):
    response = await client.post("/authors/", json=invalid_data)
    assert response.status_code == 422
    errors = response.json()["detail"]
    assert expected_error in str(errors)


@pytest.mark.read
@pytest.mark.author
async def test_get_authors(client):
    create_resp = await client.post("/authors/", json={"name": "Л. Толстой", "bio": ""})
    author_id = create_resp.json()["id"]

    response = await client.get("/authors/")
    assert response.status_code == 200
    authors = response.json()
    # ВНИМАНИЕ: в изолированной тестовой среде авторов будет ровно 1, т.к. БД очищается после каждого теста
    assert len(authors) == 1
    assert authors[0]["name"] == "Л. Толстой"


@pytest.mark.update
@pytest.mark.author
async def test_update_author(client):
    create_resp = await client.post("/authors/", json={"name": "Старый автор", "bio": "Старая биография"})
    author_id = create_resp.json()["id"]

    update_data = {"name": "Обновлённый автор", "bio": "Обновлённая биография"}
    response = await client.put(f"/authors/{author_id}", json=update_data)

    assert response.status_code == 200
    updated_author = response.json()
    assert updated_author["name"] == update_data["name"]
    assert updated_author["bio"] == update_data["bio"]
    assert "id" in updated_author


@pytest.mark.read
@pytest.mark.author
async def test_get_single_author(client):
    create_resp = await client.post("/authors/", json={"name": "Лев Толстой", "bio": ""})
    author_id = create_resp.json()["id"]

    response = await client.get(f"/authors/{author_id}")
    assert response.status_code == 200
    author = response.json()
    assert author["name"] == "Лев Толстой"
    assert author["id"] == author_id


@pytest.mark.delete
@pytest.mark.cascade
@pytest.mark.author
async def test_delete_author_with_books(client):
    author_resp = await client.post("/authors/", json={"name": "Каскадный автор", "bio": "Для теста"})
    author_id = author_resp.json()["id"]

    book_resp = await client.post("/books/", json={
        "title": "Каскадная книга",
        "author_id": author_id,
        "year": 2025,
        "pages": 250
    })
    book_id = book_resp.json()["id"]

    delete_resp = await client.delete(f"/authors/{author_id}")
    assert delete_resp.status_code == 200

    book_check = await client.get(f"/books/{book_id}")
    assert book_check.status_code == 404


@pytest.mark.parametrize(
    "long_data, max_length, field",
    [
        ({"name": "a" * 101}, 100, "name"),
        ({"bio": "b" * 501}, 500, "bio")
    ]
)
@pytest.mark.validation
@pytest.mark.author
async def test_author_field_length_validation(client, long_data, max_length, field):
    response = await client.post("/authors/", json=long_data)
    assert response.status_code == 422
    error_msg = f"String should have at most {max_length} characters"
    errors = response.json()["detail"]
    assert any(error_msg in str(e) for e in errors)
    assert any(field in str(e) for e in errors)


@pytest.mark.read
@pytest.mark.author
async def test_get_nonexistent_author(client):
    response = await client.get("/authors/99999")
    assert response.status_code == 404
    assert "Author not found" in response.json()["detail"]


@pytest.mark.update
@pytest.mark.author
async def test_partial_update_author(client):
    create_resp = await client.post("/authors/", json={"name": "Частичный автор", "bio": "Исходная биография"})
    author_id = create_resp.json()["id"]

    response = await client.patch(f"/authors/{author_id}", json={"bio": "Обновлённая биография"})
    assert response.status_code == 200
    updated = response.json()
    assert updated["name"] == "Частичный автор"
    assert updated["bio"] == "Обновлённая биография"
