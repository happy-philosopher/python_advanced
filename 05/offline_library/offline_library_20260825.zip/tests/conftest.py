import sys
from pathlib import Path
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import StaticPool
import os


ROOT_DIR = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT_DIR / "src"
sys.path.insert(0, str(ROOT_DIR))
sys.path.insert(0, str(SRC_DIR))


from src.main import app
from src.app.database import get_db
from src.app.models import Base


# Путь к тестовой БД
TEST_DB_PATH = "test_offline_library.db"
TEST_DB_URL = f"sqlite+aiosqlite:///{TEST_DB_PATH}"


@pytest_asyncio.fixture(scope="session")
async def engine():
    # Удаляем старый файл, если он существует (игнорируем ошибки)
    try:
        if os.path.exists(TEST_DB_PATH):
            os.unlink(TEST_DB_PATH)
    except PermissionError:
        pass  # файл может быть занят, но мы пересоздадим таблицы

    engine = create_async_engine(
        TEST_DB_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )

    # Создаём все таблицы
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield engine

    # Закрываем движок
    await engine.dispose()

    # Удаляем файл после завершения всех тестов (игнорируем ошибки)
    try:
        if os.path.exists(TEST_DB_PATH):
            os.unlink(TEST_DB_PATH)
    except PermissionError:
        pass


@pytest_asyncio.fixture(scope="function")
async def db_session(engine):
    """
    Создаёт сессию с транзакцией, которая будет откатываться после каждого теста.
    Это гарантирует, что тесты не влияют друг на друга.
    """
    async_session = async_sessionmaker(engine, expire_on_commit=False)
    async with async_session() as session:
        async with session.begin():
            yield session
        # Здесь транзакция откатывается, так как мы не вызывали commit()


@pytest_asyncio.fixture
async def override_get_db(db_session):
    async def _override_get_db():
        yield db_session
    return _override_get_db


@pytest_asyncio.fixture
async def client(override_get_db):
    app.dependency_overrides[get_db] = override_get_db
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.clear()
