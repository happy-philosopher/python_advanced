import pytest


@pytest.mark.create
@pytest.mark.book
async def test_create_book(client):
    author_resp = await client.post("/authors/", json={"name": "Автор для теста", "bio": "Био"})
    author_id = author_resp.json()["id"]

    book_data = {"title": "Новая книга", "author_id": author_id, "year": 2026, "pages": 300}
    response = await client.post("/books/", json=book_data)
    assert response.status_code == 201
    book = response.json()
    assert book["title"] == book_data["title"]
    assert book["year"] == book_data["year"]
    assert book["pages"] == book_data["pages"]
    assert book["author_id"] == author_id


@pytest.mark.parametrize(
    "invalid_data, expected_error",
    [
        ({"title": 123}, "Input should be a valid string"),
        ({"year": "2026"}, "Input should be a valid integer"),
        ({"pages": "300"}, "Input should be a valid integer"),
        ({"author_id": "abc"}, "Input should be a valid integer"),
        ({}, "Field required"),
        ({"title": "Книга", "year": 2026, "pages": 300}, "Field required")
    ]
)
@pytest.mark.validation
@pytest.mark.book
async def test_invalid_create_book(client, invalid_data, expected_error):
    response = await client.post("/books/", json=invalid_data)
    assert response.status_code == 422
    errors = response.json()["detail"]
    assert expected_error in str(errors)


@pytest.mark.read
@pytest.mark.book
async def test_get_books(client):
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    await client.post("/books/", json={"title": "Тестовая книга", "author_id": author_id, "year": 2026, "pages": 300})

    response = await client.get("/books/")
    assert response.status_code == 200
    books = response.json()
    assert len(books) == 1
    assert books[0]["title"] == "Тестовая книга"


@pytest.mark.update
@pytest.mark.book
async def test_update_book(client):
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    create_resp = await client.post("/books/", json={"title": "Старая книга", "author_id": author_id, "year": 2026, "pages": 300})
    book_id = create_resp.json()["id"]

    update_data = {"title": "Обновленная книга", "year": 2027}
    response = await client.put(f"/books/{book_id}", json=update_data)
    assert response.status_code == 200
    updated_book = response.json()
    assert updated_book["title"] == "Обновленная книга"
    assert updated_book["year"] == 2027
    assert updated_book["pages"] == 300


@pytest.mark.delete
@pytest.mark.book
async def test_delete_book(client):
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    create_resp = await client.post("/books/", json={"title": "Книга для удаления", "author_id": author_id, "year": 2026, "pages": 300})
    book_id = create_resp.json()["id"]

    response = await client.delete(f"/books/{book_id}")
    assert response.status_code == 200
    get_resp = await client.get(f"/books/{book_id}")
    assert get_resp.status_code == 404


@pytest.mark.parametrize(
    "year, expected_error",
    [
        (2026, None),
        (0, "Input should be greater than 0"),
        (-100, "Input should be greater than 0"),
        (99999, "Input should be less than or equal to 99999")
    ]
)
@pytest.mark.validation
@pytest.mark.book
async def test_year_validation(client, year, expected_error):
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    data = {"title": "Тестовая книга", "author_id": author_id, "year": year, "pages": 300}
    response = await client.post("/books/", json=data)
    if expected_error:
        assert response.status_code == 422
        assert expected_error in str(response.json()["detail"])
    else:
        assert response.status_code == 201


@pytest.mark.parametrize(
    "pages, expected_error",
    [
        (300, None),
        (0, "Input should be greater than 0"),
        (-10, "Input should be greater than 0"),
        (1000000, "Input should be less than or equal to 1000000")
    ]
)
@pytest.mark.validation
@pytest.mark.book
async def test_pages_validation(client, pages, expected_error):
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    data = {"title": "Тестовая книга", "author_id": author_id, "year": 2026, "pages": pages}
    response = await client.post("/books/", json=data)
    if expected_error:
        assert response.status_code == 422
        assert expected_error in str(response.json()["detail"])
    else:
        assert response.status_code == 201


@pytest.mark.parametrize(
    "title_length, expected_error",
    [
        (200, None),
        (201, "String should have at most 200 characters"),
        (1, None),
        (0, "String should have at least 1 character")
    ]
)
@pytest.mark.validation
@pytest.mark.book
async def test_title_length_validation(client, title_length, expected_error):
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    title = "a" * title_length if title_length > 0 else ""
    data = {"title": title, "author_id": author_id, "year": 2026, "pages": 300}
    response = await client.post("/books/", json=data)
    if expected_error:
        assert response.status_code == 422
        assert expected_error in str(response.json()["detail"])
    else:
        assert response.status_code == 201


@pytest.mark.delete
@pytest.mark.book
async def test_delete_book_cascade(client):
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    create_resp = await client.post("/books/", json={"title": "Книга", "author_id": author_id, "year": 2026, "pages": 300})
    book_id = create_resp.json()["id"]

    client_resp = await client.post("/clients/", json={"full_name": "Клиент", "phone": "+79991234567", "email": "client@test.ru"})
    client_id = client_resp.json()["id"]
    await client.post("/orders/", json={"client_id": client_id, "book_id": book_id, "issue_date": "2026-07-27"})

    response = await client.delete(f"/books/{book_id}")
    assert response.status_code == 200

    get_book_resp = await client.get(f"/books/{book_id}")
    assert get_book_resp.status_code == 404

    get_orders_resp = await client.get("/orders/")
    orders = get_orders_resp.json()
    assert not any(order["book_id"] == book_id for order in orders)
