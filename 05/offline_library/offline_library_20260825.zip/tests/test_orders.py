import pytest


@pytest.mark.create
@pytest.mark.order
async def test_create_order(client):
    client_resp = await client.post("/clients/", json={"full_name": "Клиент", "phone": "+79991234567", "email": "client@test.ru"})
    client_id = client_resp.json()["id"]
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    book_resp = await client.post("/books/", json={"title": "Книга", "author_id": author_id, "year": 2026, "pages": 300})
    book_id = book_resp.json()["id"]

    order_data = {"client_id": client_id, "book_id": book_id, "issue_date": "2026-07-27"}
    response = await client.post("/orders/", json=order_data)
    assert response.status_code == 201
    order = response.json()
    assert order["client_id"] == client_id
    assert order["book_id"] == book_id
    assert order["issue_date"] == "2026-07-27"
    assert order["return_date"] is None


@pytest.mark.parametrize(
    "invalid_data, expected_error",
    [
        ({"client_id": 1, "book_id": 1, "issue_date": "2026-07-27"}, None),
        ({"client_id": 1, "book_id": 1}, "Field required"),
        ({"book_id": 1, "issue_date": "2026-07-27"}, "Field required"),
        ({"client_id": 1, "issue_date": "2026-07-27"}, "Field required"),
        ({"client_id": 1, "book_id": 1, "issue_date": "invalid_date"}, "Invalid date format"),
        ({"client_id": "abc", "book_id": 1, "issue_date": "2026-07-27"}, "Input should be a valid integer"),
        ({"client_id": 1, "book_id": "abc", "issue_date": "2026-07-27"}, "Input should be a valid integer")
    ]
)
@pytest.mark.validation
@pytest.mark.order
async def test_invalid_create_order(client, invalid_data, expected_error):
    # Если данные валидны, но сущностей нет, будет 404, поэтому пропускаем проверку ожидаемых ошибок для этого случая
    if expected_error is None:
        # Для валидного случая создадим сущности и проверим успех
        client_resp = await client.post("/clients/", json={"full_name": "Клиент", "phone": "+79991234567", "email": "client@test.ru"})
        client_id = client_resp.json()["id"]
        author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
        author_id = author_resp.json()["id"]
        book_resp = await client.post("/books/", json={"title": "Книга", "author_id": author_id, "year": 2026, "pages": 300})
        book_id = book_resp.json()["id"]
        data = {"client_id": client_id, "book_id": book_id, "issue_date": "2026-07-27"}
        response = await client.post("/orders/", json=data)
        assert response.status_code == 201
    else:
        # Для невалидных данных отправляем без создания сущностей, ожидаем 422
        response = await client.post("/orders/", json=invalid_data)
        assert response.status_code == 422
        assert expected_error in str(response.json()["detail"])


@pytest.mark.update
@pytest.mark.order
async def test_update_order(client):
    client_resp = await client.post("/clients/", json={"full_name": "Клиент", "phone": "+79991234567", "email": "client@test.ru"})
    client_id = client_resp.json()["id"]
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    book_resp = await client.post("/books/", json={"title": "Книга", "author_id": author_id, "year": 2026, "pages": 300})
    book_id = book_resp.json()["id"]
    create_resp = await client.post("/orders/", json={"client_id": client_id, "book_id": book_id, "issue_date": "2026-07-27"})
    order_id = create_resp.json()["id"]

    update_data = {"return_date": "2026-08-27"}
    response = await client.put(f"/orders/{order_id}", json=update_data)
    assert response.status_code == 200
    updated = response.json()
    assert updated["return_date"] == "2026-08-27"
    assert updated["client_id"] == client_id
    assert updated["book_id"] == book_id


@pytest.mark.delete
@pytest.mark.order
async def test_delete_order(client):
    client_resp = await client.post("/clients/", json={"full_name": "Клиент", "phone": "+79991234567", "email": "client@test.ru"})
    client_id = client_resp.json()["id"]
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    book_resp = await client.post("/books/", json={"title": "Книга", "author_id": author_id, "year": 2026, "pages": 300})
    book_id = book_resp.json()["id"]
    create_resp = await client.post("/orders/", json={"client_id": client_id, "book_id": book_id, "issue_date": "2026-07-27"})
    order_id = create_resp.json()["id"]

    response = await client.delete(f"/orders/{order_id}")
    assert response.status_code == 200
    get_resp = await client.get(f"/orders/{order_id}")
    assert get_resp.status_code == 404


@pytest.mark.parametrize(
    "issue_date, return_date, expected_error",
    [
        ("2026-07-27", "2026-08-27", None),
        ("2026-07-27", "2026-07-26", "return_date must be after issue_date"),
        ("invalid-date", "2026-08-27", "Invalid date format"),
        ("2026-07-27", "invalid-date", "Invalid date format"),
        (None, "2026-08-27", "Field required"),
        ("2026-07-27", None, "valid case with no return date")
    ]
)
@pytest.mark.validation
@pytest.mark.order
async def test_order_date_validation(client, issue_date, return_date, expected_error):
    # Создаём сущности
    client_resp = await client.post("/clients/", json={"full_name": "Клиент", "phone": "+79991234567", "email": "client@test.ru"})
    client_id = client_resp.json()["id"]
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    book_resp = await client.post("/books/", json={"title": "Книга", "author_id": author_id, "year": 2026, "pages": 300})
    book_id = book_resp.json()["id"]

    order_data = {"client_id": client_id, "book_id": book_id, "issue_date": issue_date}
    if return_date is not None:
        order_data["return_date"] = return_date

    response = await client.post("/orders/", json=order_data)
    if expected_error:
        assert response.status_code == 422
        assert expected_error in str(response.json()["detail"])
    else:
        assert response.status_code == 201


@pytest.mark.parametrize(
    "client_id, book_id, expected_error",
    [
        (1, 1, "Client not found"),
        (-1, 1, "Client not found"),
        (1, -1, "Book not found"),
        (0, 1, "Client not found"),
        (1, 0, "Book not found"),
        ("abc", 1, "Input should be a valid integer"),
        (1, "abc", "Input should be a valid integer")
    ]
)
@pytest.mark.validation
@pytest.mark.order
async def test_order_foreign_keys_validation(client, client_id, book_id, expected_error):
    # Создаём сущности, но используем валидные ID? Здесь мы передаём несуществующие ID, чтобы проверить 404
    # Для этого не создаём клиента и книгу с такими ID, но для "abc" - проверка типа.
    order_data = {"client_id": client_id, "book_id": book_id, "issue_date": "2026-07-27"}
    response = await client.post("/orders/", json=order_data)
    # Если ожидается ошибка валидации типа, будет 422, иначе 404
    if expected_error == "Input should be a valid integer":
        assert response.status_code == 422
        assert expected_error in str(response.json()["detail"])
    else:
        assert response.status_code == 404
        assert expected_error in response.json()["detail"]


@pytest.mark.parametrize(
    "book_id, expected_error",
    [
        (1, None),  # валидный случай, но требуется создать книгу с id 1? Нет, мы переделаем
    ]
)
@pytest.mark.validation
@pytest.mark.order
async def test_book_availability_validation(client, book_id, expected_error):
    # Создаём клиента, книгу
    client_resp = await client.post("/clients/", json={"full_name": "Клиент", "phone": "+79991234567", "email": "client@test.ru"})
    client_id = client_resp.json()["id"]
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    book_resp = await client.post("/books/", json={"title": "Книга", "author_id": author_id, "year": 2026, "pages": 300})
    real_book_id = book_resp.json()["id"]

    first_order = await client.post("/orders/", json={"client_id": client_id, "book_id": real_book_id, "issue_date": "2026-07-27"})
    assert first_order.status_code == 201
    second_order = await client.post("/orders/", json={"client_id": client_id, "book_id": real_book_id, "issue_date": "2026-07-27"})
    assert second_order.status_code == 400
    assert "Книга уже выдана" in second_order.json()["detail"]


@pytest.mark.parametrize(
    "return_date, expected_status",
    [
        ("2026-07-27", 200),
        ("2026-07-26", 400),
        ("invalid-date", 422),
        (None, 200)
    ]
)
@pytest.mark.update
@pytest.mark.order
async def test_update_return_date(client, return_date, expected_status):
    client_resp = await client.post("/clients/", json={"full_name": "Клиент", "phone": "+79991234567", "email": "client@test.ru"})
    client_id = client_resp.json()["id"]
    author_resp = await client.post("/authors/", json={"name": "Автор", "bio": "Био"})
    author_id = author_resp.json()["id"]
    book_resp = await client.post("/books/", json={"title": "Книга", "author_id": author_id, "year": 2026, "pages": 300})
    book_id = book_resp.json()["id"]
    create_resp = await client.post("/orders/", json={"client_id": client_id, "book_id": book_id, "issue_date": "2026-07-27"})
    order_id = create_resp.json()["id"]

    update_data = {"return_date": return_date}
    response = await client.put(f"/orders/{order_id}", json=update_data)
    assert response.status_code == expected_status
